# Matrice croisée — Stratégie × tactique

## Présents dans les deux Top 12

| Personnage | Rang stratégie | Rang tactique | Lecture |
|---|---:|---:|---|
| Napoléon Bonaparte | 4 | 2 | Maître complet, mais tacticien supérieur à son bilan final de grande stratégie |
| Scipion l’Africain | 5 | 5 | Profil le plus équilibré entre apprentissage, campagne, bataille et résultat politique |

## Stratèges nettement supérieurs à leur profil tactique

- Gengis Khan — système impérial et organisation de la guerre.
- Otto von Bismarck — choix et limitation des guerres, diplomatie et ordre politique.
- Mao Zedong — mobilisation politique et temporalité révolutionnaire.
- Tokugawa Ieyasu — coalition, patience et stabilisation.
- Auguste — institutionnalisation de la victoire.
- Clausewitz — puissance théorique.
- Sun Tzu — corpus stratégique.
- Marshall — construction d’un appareil de guerre global.
- Giáp — articulation politico-militaire de l’asymétrie et du temps.

## Tacticiens nettement supérieurs à leur profil de grande stratégie

- Alexandre le Grand — n°1 tactique, mais 17e stratégique en raison de la succession et de la stabilisation.
- Hannibal Barca — pic tactique immense, incapacité à convertir ses victoires en décision politique contre Rome.
- Jules César — tacticien de premier ordre ; sa carrière politico-stratégique n’a pas été retenue parmi les 20 finalistes stratégiques.
- Yi Sun-sin — tactique navale exceptionnelle, rôle stratégique plus spécialisé.
- Horatio Nelson — rupture tactique navale, stratégie nationale définie au-dessus de lui.
- Épaminondas — innovation de bataille majeure, échantillon stratégique plus limité.
- Souvorov — commandement tactique et opératif supérieur à sa contribution de grande stratégie.
- Marlborough — grand commandant de coalition, mais non auteur principal des finalités politiques britanniques.
- Wellington — robustesse tactique exceptionnelle ; profil politico-stratégique moins transformateur.
- Bélisaire — économie des moyens et adaptation sous contraintes.

## Maîtres de l’art opératif identifiés mais non classés comme tels

- Helmuth von Moltke l’Ancien
- Subutaï
- Konstantin Rokossovski

Leur position dans les listes montre pourquoi la séparation des niveaux est nécessaire : ils peuvent être extraordinairement importants sans être automatiquement Top 12 en tactique ou en grande stratégie.

## Conclusion

Le classement croisé confirme l’intérêt de la séparation initiale : **la capacité à gagner des batailles et la capacité à gagner politiquement une guerre ne sont pas la même compétence**.

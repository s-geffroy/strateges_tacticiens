# Classement final — Les 12 plus grands tacticiens

> **Statut : classement final arrêté.**

## Top 12

| Rang | Candidat | Confiance Top 12 | Motif synthétique |
|---:|---|---|---|
| **1** | **Alexandre le Grand** | Très élevée | Meilleur équilibre entre pic, constance, diversité des situations, commandement personnel et forces combinées. |
| **2** | **Napoléon Bonaparte** | Très élevée | Répétabilité tactique exceptionnelle à grande échelle, malgré un déclin tardif. |
| **3** | **Hannibal Barca** | Très élevée | Pic tactique probablement maximal avec Cannes et remarquable capacité à modeler la réaction adverse. |
| **4** | **Jules César** | Très élevée | Polyvalence extrême : bataille, siège, ingénierie, improvisation et commandement dans la crise. |
| **5** | **Scipion l’Africain** | Très élevée | Capacité rare à apprendre de l’adversaire et à reconstruire le dispositif pour le neutraliser. |
| **6** | **Yi Sun-sin** | Élevée | Exploitation exceptionnelle du terrain maritime, des courants, du feu et de l’économie des moyens. |
| **7** | **Horatio Nelson** | Élevée | Rupture du dispositif naval, commandement par intention et culture d’initiative. |
| **8** | **Épaminondas** | Élevée | Innovation structurelle du dispositif hoplitique ; petit échantillon empêchant un rang supérieur. |
| **9** | **Alexandre Souvorov** | Élevée | Vitesse, simplicité, moral et offensive ; légère contamination par l’art opératif. |
| **10** | **John Churchill, duc de Marlborough** | Élevée | Très grande synchronisation de coalition et maîtrise de la fixation, du déplacement de l’effort et de l’exploitation. |
| **11** | **Arthur Wellesley, duc de Wellington** | Élevée | Génie de la robustesse : terrain, discipline, feu, réserves et réduction systématique du risque. |
| **12** | **Bélisaire** | Moyenne | Meilleure économie des moyens parmi les candidats de frontière ; adaptation supérieure dans des situations dégradées. |

## Huit prétendants immédiats

| Rang | Candidat | Confiance / statut | Motif de non-admission |
|---:|---|---|---|
| **13** | **Frédéric II de Prusse** | Élevée | Chefs-d’œuvre et profondeur de carrière, mais irrégularité, pertes et plusieurs décisions tactiques défaillantes. |
| **14** | **Jan Žižka** | Moyenne | Innovation hussite traçable et efficace, mais système et théâtre plus spécialisés. |
| **15** | **Khalid ibn al-Walid** | Faible à moyenne | Potentiel très élevé, mais résolution documentaire trop faible pour une douzième place mondiale. |
| **16** | **Louis-Nicolas Davout** | Élevée | Auerstaedt est un chef-d’œuvre, mais l’échantillon de commandement autonome reste trop étroit. |
| **17** | **Nader Shah** | Moyenne à élevée | Maîtrise du feu mobile et de la manœuvre, mais part opérative importante et adversaires de qualité inégale. |
| **18** | **Han Xin** | Faible à moyenne | Créativité potentiellement exceptionnelle, mais sources trop tardives et littéraires pour un rang précis. |
| **19** | **Subutaï** | Moyenne | Génie surtout opératif : coordination de colonnes et campagnes continentales plutôt que conduite tactique stricte. |
| **20** | **Konstantin Rokossovski** | Très élevée | Maître de l’art opératif interarmes ; la preuve tactique personnelle est plus indirecte. |

## Lecture du rang

Le rang récompense la transformation directe d’une situation de combat par la lecture, la conception, l’exécution et l’adaptation. Les performances principalement opératives ne suffisent pas.

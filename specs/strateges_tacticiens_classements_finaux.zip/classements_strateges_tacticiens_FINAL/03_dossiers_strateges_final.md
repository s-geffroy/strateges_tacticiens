# Vingt dossiers comparatifs finaux — Stratèges

> **Statut : dossiers finaux.** Les bandes provisoires du travail V2 sont conservées dans le corps comme trace du raisonnement, mais la position finale ci-dessous prévaut.

## 1. Gengis Khan

**Position finale : 1e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Construit un système de guerre et de conquête extensible qui dépasse sa personne.

- **Profil :** fondateur d’empire et architecte politico-militaire.
- **Cas maître :** unification mongole puis campagnes contre les Xia occidentaux, les Jin et le Khwarezm.
- **Avantage décisif :** système combinant mobilité, discipline, renseignement, commandement décentralisé, intégration des spécialistes et terreur instrumentale.
- **Limite :** une partie de l’expansion mondiale et de la formalisation impériale appartient à ses successeurs.
- **Attribution :** très forte pour le système initial ; moyenne pour les performances impériales postérieures.
- **Confiance documentaire :** moyenne à élevée.
- **Bande provisoire :** Top 3 robuste.
- **Verdict :** candidat incontestable au podium ; la première place exige de ne pas lui attribuer rétrospectivement toute la réussite mongole.

## 2. Otto von Bismarck

**Position finale : 2e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Maîtrise exemplaire de la limitation politique de la guerre et de l’après-victoire.

- **Profil :** grand stratège d’État.
- **Cas maître :** unification allemande par des guerres limitées, préparées diplomatiquement et arrêtées une fois le but politique atteint.
- **Avantage décisif :** limitation des objectifs, isolement de l’adversaire, maîtrise de l’après-guerre.
- **Limite :** ne conçoit ni ne conduit les opérations ; dépend du système prussien et de Moltke.
- **Attribution :** très forte sur les fins et la diplomatie ; faible sur l’exécution militaire.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 8 probable.
- **Verdict :** son exclusion du Top 12 serait incohérente avec une définition réellement politico-militaire de la stratégie.

## 3. Mao Zedong

**Position finale : 3e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Intègre politique, mobilisation, temps long, guerre irrégulière et guerre conventionnelle.

- **Profil :** stratège révolutionnaire et politico-militaire.
- **Cas maître :** survie, expansion puis victoire du mouvement communiste chinois.
- **Avantage décisif :** articulation entre organisation politique, mobilisation paysanne, contrôle territorial, temps long, guérilla et guerre conventionnelle.
- **Limite :** transférabilité partielle hors des guerres révolutionnaires ; erreurs ultérieures de gouvernement et de guerre.
- **Attribution :** forte sur la doctrine et l’orientation ; collective dans l’exécution.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 5 probable.
- **Verdict :** géant de la stratégie révolutionnaire ; le rang mondial n°2 suppose une universalité encore non démontrée.

## 4. Napoléon Bonaparte

**Position finale : 4e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Maîtrise militaire exceptionnelle, limitée par l’incapacité finale à stabiliser l’ordre européen.

- **Profil :** commandant-stratège de campagnes.
- **Cas maître :** Italie, Ulm–Austerlitz et campagne de 1806.
- **Avantage décisif :** transformation de l’espace, du tempo et de l’organisation en décisions militaires aux effets politiques immédiats.
- **Limite :** objectifs croissants, ordre européen instable, Espagne, Russie et coalitions répétées.
- **Attribution :** très forte, avec concentration du commandement politique et militaire.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 5–8, avec plafond de grande stratégie.
- **Verdict :** son échec final interdit le sommet, pas le premier tiers.

## 5. Scipion l’Africain

**Position finale : 5e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Déplace le théâtre, désarticule la base carthaginoise et convertit l’apprentissage en décision politique.

- **Profil :** stratège adaptatif.
- **Cas maître :** Espagne, alliance numide, déplacement de la guerre en Afrique et Zama.
- **Avantage décisif :** compréhension du système carthaginois et attaque de ses ressources politiques et militaires.
- **Limite :** échantillon plus réduit ; bénéficie de la résilience institutionnelle romaine.
- **Attribution :** forte sur les campagnes d’Espagne et d’Afrique.
- **Confiance documentaire :** moyenne à élevée.
- **Bande provisoire :** Top 8–12 probable.
- **Verdict :** l’un des rares candidats excellant simultanément en stratégie, opératif et tactique.

## 6. Tokugawa Ieyasu

**Position finale : 6e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Allie patience, coalition, conservation des forces et institutionnalisation durable de la victoire.

- **Profil :** unificateur patient et fondateur de régime.
- **Cas maître :** coalitions, Sekigahara, neutralisation des rivaux et installation du shogunat.
- **Avantage décisif :** patience, conservation des forces, exploitation des divisions adverses et conversion de la victoire en stabilité.
- **Limite :** s’appuie sur les transformations engagées par Nobunaga et Hideyoshi.
- **Attribution :** forte, mais cumulative.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 10–12 probable.
- **Verdict :** sous-évalué dans les panthéons occidentaux ; candidat sérieux au Top 12.

## 7. Auguste

**Position finale : 7e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Transforme la victoire civile en architecture militaire et politique durable, avec attribution opérationnelle partagée.

- **Profil :** constructeur d’ordre impérial.
- **Cas maître :** conversion des guerres civiles en monopole militaire, armée permanente et régime durable.
- **Avantage décisif :** transformation de la victoire en institutions, stabilisation du commandement et organisation des frontières.
- **Limite :** Agrippa et les légats portent une part essentielle de la conduite militaire.
- **Attribution :** forte sur l’architecture institutionnelle ; moyenne à faible sur les campagnes.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 10 probable.
- **Verdict :** très grand stratège institutionnel ; un podium mondial surestimerait sa contribution militaire personnelle.

## 8. Mehmed II

**Position finale : 8e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Combine technologie, siège, diplomatie, coercition et consolidation impériale.

- **Profil :** conquérant institutionnel ottoman.
- **Cas maître :** prise de Constantinople et consolidation impériale.
- **Avantage décisif :** combinaison de siège, flotte, artillerie, diplomatie, logistique et administration.
- **Limite :** durabilité ottomane également redevable aux structures antérieures et aux successeurs.
- **Attribution :** forte sur Constantinople et la consolidation initiale.
- **Confiance documentaire :** moyenne à élevée.
- **Bande provisoire :** frontière du Top 12.
- **Verdict :** candidat crédible, surtout si la combinaison technologie–politique–institution est fortement valorisée.

## 9. Carl von Clausewitz

**Position finale : 9e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Fournit la théorie la plus puissante de la guerre comme instrument politique, malgré une validation personnelle limitée.

- **Profil :** théoricien de la stratégie.
- **Cas maître :** conceptualisation de la guerre comme instrument politique soumis à la friction et à l’interaction adverse.
- **Avantage décisif :** grammaire puissante des fins, moyens, escalade, friction et primauté du politique.
- **Limite :** œuvre inachevée et faible commandement autonome.
- **Attribution :** très forte sur le corpus ; faible sur la performance militaire personnelle.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 12 si les théoriciens sont pleinement admissibles.
- **Verdict :** sa place dépend du poids donné à l’influence théorique, non de la qualité intrinsèque de son œuvre.

## 10. Sun Tzu — corpus attribué

**Position finale : 10e sur 20 — Top 12.**  
**Confiance : Élevée pour le corpus.**  
**Motif final :** Corpus majeur sur information, tromperie, asymétrie et économie de la coercition ; l’individu historique demeure incertain.

- **Profil :** corpus stratégique classique.
- **Cas maître :** théorie de l’information, de la tromperie, de l’économie de la force et de la victoire préparée avant le combat.
- **Avantage décisif :** transférabilité conceptuelle, adaptation et asymétrie.
- **Limite :** auteur, datation et biographie incertains ; validation opérationnelle personnelle presque impossible.
- **Attribution :** forte au corpus, faible à l’individu historique.
- **Confiance documentaire :** moyenne sur l’origine, très élevée sur l’influence.
- **Bande provisoire :** Top 12 doctrinal.
- **Verdict :** classer le corpus, non une biographie partiellement légendaire.

## 11. George C. Marshall

**Position finale : 11e sur 20 — Top 12.**  
**Confiance : Moyenne à élevée.**  
**Motif final :** Construit l’appareil américain capable de soutenir une guerre mondiale et sélectionne les instruments humains de son exécution.

- **Profil :** organisateur de guerre globale.
- **Cas maître :** expansion de l’armée américaine, sélection des commandants et planification alliée.
- **Avantage décisif :** conversion de la puissance industrielle et humaine en appareil militaire mondial.
- **Limite :** stratégie alliée collective et politiquement dirigée par Roosevelt et Churchill.
- **Attribution :** forte sur l’organisation américaine ; partagée sur la grande stratégie alliée.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** frontière du Top 12.
- **Verdict :** candidat majeur, mais sa cinquième place initiale était excessive.

## 12. Võ Nguyên Giáp

**Position finale : 12e sur 20 — Top 12.**  
**Confiance : Moyenne.**  
**Motif final :** Résultat politique disproportionné aux moyens initiaux ; attribution collective et coûts empêchent un rang supérieur.

- **Profil :** stratège révolutionnaire et conventionnel.
- **Cas maître :** passage de la guérilla à la guerre conventionnelle et réunification vietnamienne.
- **Avantage décisif :** temps long, mobilisation politique, endurance et adaptation des formes de guerre.
- **Limite :** pertes considérables, échecs opérationnels, rôle du Parti et soutien extérieur.
- **Attribution :** forte mais collective.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 15–20.
- **Verdict :** résultat stratégique majeur ; la personnalisation doit être corrigée.

## 13. Chester W. Nimitz

**Position finale : 13e sur 20 — prétendant immédiat.**  
**Confiance : Moyenne.**  
**Motif final :** Commandement de théâtre exceptionnel, mais contribution moins globale que Marshall et moins politico-stratégique que Giáp.

- **Profil :** stratège de théâtre maritime.
- **Cas maître :** Pacifique central, coordination flotte–aviation–amphibie et progression insulaire.
- **Avantage décisif :** apprentissage, délégation, intégration interarmées et exploitation du renseignement.
- **Limite :** puissance industrielle américaine et partage du théâtre avec MacArthur.
- **Attribution :** forte sur le Pacifique central ; collective au niveau national.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 15–20.
- **Verdict :** finaliste solide, mais le Top 12 exige un duel serré avec Marshall et Eisenhower.

## 14. Frédéric II de Prusse

**Position finale : 14e sur 20 — prétendant immédiat.**  
**Confiance : Moyenne.**  
**Motif final :** Survie remarquable face à une coalition supérieure, mais risques auto-infligés et dépendance aux événements extérieurs.

- **Profil :** stratège de survie et commandant de campagne.
- **Cas maître :** maintien de la Prusse pendant la guerre de Sept Ans.
- **Avantage décisif :** vitesse, position centrale, reconstitution des forces et refus de l’effondrement.
- **Limite :** prises de risque extrêmes, lourdes pertes, erreurs majeures et retournement russe de 1762.
- **Attribution :** très forte sur les opérations ; plus discutée sur l’issue politique finale.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** places 10–16.
- **Verdict :** Top 12 possible ; la survie prussienne ne doit pas être réécrite comme un contrôle complet de la guerre.

## 15. Pierre le Grand

**Position finale : 15e sur 20 — prétendant immédiat.**  
**Confiance : Moyenne.**  
**Motif final :** Transformation militaire et étatique majeure, mais victoire lente, coûteuse et partiellement structurelle.

- **Profil :** transformateur d’État et de puissance militaire.
- **Cas maître :** réformes militaires et navales, apprentissage après Narva et Grande Guerre du Nord.
- **Avantage décisif :** apprentissage, construction institutionnelle et persistance.
- **Limite :** coûts immenses, succès lent et avantages structurels russes croissants.
- **Attribution :** forte sur la transformation ; partagée sur les campagnes.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 15–20.
- **Verdict :** grand transformateur ; sa quatrième place initiale était indéfendable.

## 16. Dwight D. Eisenhower

**Position finale : 16e sur 20 — prétendant immédiat.**  
**Confiance : Moyenne.**  
**Motif final :** Commandant de coalition remarquable, mais auteur seulement partiel de la grande stratégie alliée.

- **Profil :** commandant stratégique de coalition.
- **Cas maître :** Méditerranée, Overlord et campagne d’Europe occidentale.
- **Avantage décisif :** arbitrage entre commandants, gestion politique et maintien de l’unité d’effort.
- **Limite :** n’invente pas seul la stratégie alliée et dispose d’une supériorité matérielle massive en 1944.
- **Attribution :** forte sur la coalition ; partagée sur la stratégie globale.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 15–20.
- **Verdict :** excellent, mais probablement hors Top 12 mondial.

## 17. Alexandre le Grand

**Position finale : 17e sur 20 — prétendant immédiat.**  
**Confiance : Élevée.**  
**Motif final :** Conquête fulgurante et maîtrise militaire immense, mais faiblesse de la succession et de la stabilisation.

- **Profil :** conquérant et commandant-stratège.
- **Cas maître :** destruction de l’Empire achéménide par campagnes rapides et adaptation successive.
- **Avantage décisif :** unité du commandement, audace, vitesse et exploitation de la victoire.
- **Limite :** succession non réglée et fragmentation rapide de l’empire.
- **Attribution :** très forte sur la conquête ; faible sur la durabilité.
- **Confiance documentaire :** moyenne à élevée.
- **Bande provisoire :** Top 15–20 stratégique ; podium tactique.
- **Verdict :** génie militaire absolu, grande stratégie incomplète.

## 18. Helmuth von Moltke l’Ancien

**Position finale : 18e sur 20 — prétendant immédiat.**  
**Confiance : Élevée.**  
**Motif final :** Maître de l’art opératif ; autonomie politico-stratégique limitée par la primauté de Bismarck.

- **Profil :** maître de l’art opératif et chef d’état-major.
- **Cas maître :** campagnes de 1866 et 1870, mobilisation ferroviaire et commandement par intention.
- **Avantage décisif :** système de coordination de grandes armées et adaptation après l’ouverture des hostilités.
- **Limite :** buts politiques définis par Bismarck ; tension entre logique militaire et finalité politique.
- **Attribution :** très forte sur l’opératif ; faible sur la grande stratégie politique.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 15–20, davantage opératif.
- **Verdict :** finaliste légitime, mais probablement mal catégorisé comme grand stratège généraliste.

## 19. Kautilya — Arthashastra

**Position finale : 19e sur 20 — prétendant immédiat.**  
**Confiance : Moyenne.**  
**Motif final :** Corpus systémique de gouvernement et de puissance, mais attribution et validation opérationnelle insuffisantes.

- **Profil :** corpus de gouvernement et de grande stratégie.
- **Cas maître :** intégration de la diplomatie, des alliances, du renseignement, de l’économie et de la coercition.
- **Avantage décisif :** vision systémique de la puissance et de la compétition entre États.
- **Limite :** datation, composition et attribution complexes ; lien opérationnel difficile à établir.
- **Attribution :** forte au corpus, faible à l’individu-commandant.
- **Confiance documentaire :** moyenne.
- **Bande provisoire :** Top 20 doctrinal.
- **Verdict :** comparable à Sun Tzu comme corpus, mais moins centré sur la conduite militaire.

## 20. Joseph Staline

**Position finale : 20e sur 20 — prétendant immédiat.**  
**Confiance : Élevée sur les faits, rang faible.**  
**Motif final :** Capacité de mobilisation existentielle réelle, contrebalancée par des erreurs initiales et des coûts extrêmes.

- **Profil :** chef de guerre total et organisateur de coalition.
- **Cas maître :** mobilisation soviétique, déplacement industriel et progression vers Berlin après les désastres initiaux.
- **Avantage décisif :** soutien d’une guerre existentielle, mobilisation industrielle et apprentissage partiel.
- **Limite :** purges, aveuglement de 1941, désastres initiaux, coûts humains extrêmes et responsabilité dans la fragilisation de l’Armée rouge.
- **Attribution :** forte sur le système politique ; partagée avec la Stavka et les maréchaux.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 15–20 controversé.
- **Verdict :** doit être testé sans complaisance ni exclusion morale automatique ; ses erreurs interdisent un rang élevé.

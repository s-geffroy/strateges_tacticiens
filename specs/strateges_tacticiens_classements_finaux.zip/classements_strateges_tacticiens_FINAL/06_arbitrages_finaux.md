# Arbitrages finaux

## A. Places 11–12 du classement stratégique

### Candidats

- George C. Marshall
- Võ Nguyên Giáp
- Chester W. Nimitz
- Frédéric II de Prusse

### 11. George C. Marshall — admis

**À charge :** il ne fixe pas seul les finalités politiques américaines et la stratégie alliée est un processus collectif.  
**À décharge :** il transforme une armée limitée en appareil capable de soutenir une guerre mondiale, participe à l’allocation des ressources et à la sélection des commandants.  
**Décision :** sa contribution à la création du système de puissance est plus globale que celle d’un commandant de théâtre.

### 12. Võ Nguyên Giáp — admis

**À charge :** attribution collective avec le Parti, Hô Chi Minh, Lê Duẩn et d’autres responsables ; coûts humains très élevés.  
**À décharge :** forte asymétrie initiale, articulation du temps, de la mobilisation politique et des formes de guerre, plus preuve personnelle majeure à Điện Biên Phủ.  
**Décision :** il devance Nimitz parce que le classement porte sur la transformation de la guerre en résultat politique, non sur la seule direction d’un théâtre.

### 13. Chester W. Nimitz — premier exclu

**À charge :** commandement de théâtre inscrit dans une stratégie et un système industriel/renseignement plus larges.  
**À décharge :** adaptation après Pearl Harbor, maîtrise aéronavale et amphibie, prise de risque calculée, délégation efficace.  
**Décision :** immense stratège de théâtre, mais contribution moins globale que Marshall et moins politico-stratégique que Giáp.

### 14. Frédéric II — deuxième exclu

**À charge :** risques auto-infligés, pertes, erreurs et dépendance à la défaillance de la coalition adverse et au retournement russe.  
**À décharge :** survie prussienne contre une coalition supérieure et capacité exceptionnelle à exploiter une position centrale.  
**Décision :** son génie tactique/opératif contaminait trop l’évaluation stratégique.

## B. Douzième place du classement tactique

### Candidats

- Bélisaire
- Frédéric II de Prusse
- Jan Žižka
- Khalid ibn al-Walid

### 12. Bélisaire — admis

**À charge :** sources dominées par Procope, parfois favorable au général, et plusieurs revers.  
**À décharge :** diversité exceptionnelle des situations, économie des moyens, adaptation, défense mobile et commandement de forces hétérogènes.  
**Décision :** il est le meilleur des quatre sur l’adaptation tactique en situation dégradée et la création d’un avantage avec des moyens limités.

### 13. Frédéric II — premier exclu

**À charge :** irrégularité, pertes élevées, erreurs de reconnaissance et attaques coûteuses.  
**À décharge :** profondeur documentaire et plusieurs chefs-d’œuvre dont Leuthen.  
**Décision :** le volume de preuves est supérieur à celui de Bélisaire, mais la qualité adaptative moyenne est moins élevée.

### 14. Jan Žižka — deuxième exclu

**À charge :** système très lié au théâtre bohémien, aux chariots, aux armes à feu précoces et à des adversaires initialement mal adaptés.  
**À décharge :** innovation traçable, fortification mobile, discipline d’infanterie et neutralisation de la cavalerie lourde.  
**Décision :** remarquable, mais preuve moins diversifiée que Bélisaire et Frédéric.

### 15. Khalid ibn al-Walid

**À charge :** sources tardives et reconstruction tactique trop incertaine pour un rang mondial précis.  
**À décharge :** succession de succès et forte plausibilité d’un commandement mobile et adaptatif de très haut niveau.  
**Décision :** l’incertitude documentaire, non une prétendue infériorité réelle, interdit la douzième place.

## Règle de clôture

Ces deux arbitrages ferment les seules frontières encore instables. Toute réouverture doit s’appuyer sur un élément nouveau, pas sur une préférence esthétique pour un nom ou une école militaire.

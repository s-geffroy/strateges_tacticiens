# Sources et règles documentaires

## Politique documentaire

Le classement privilégie :

1. historiographie académique récente ;
2. histoires officielles militaires lorsqu’elles sont utiles pour l’organisation et la chaîne de commandement ;
3. sources primaires avec correction de leurs biais ;
4. biographies seulement lorsqu’elles sont recoupées.

Les traditions héroïques ne sont jamais traitées comme des transcriptions littérales des décisions tactiques. Pour les figures antiques ou médiévales, l’incertitude documentaire agit d’abord sur la **confiance dans le rang**, pas comme une pénalité morale ou civilisationnelle.

## Sources de cadrage et de contrôle utilisées au cours de l’étude

### Niveaux de guerre et méthodologie

- U.S. Army University Press / Military Review, travaux sur les niveaux tactique, opératif et stratégique.
- U.S. Army Center of Military History, histoires officielles de la planification et du haut commandement pendant la Seconde Guerre mondiale.

### Grande stratégie

- *The Cambridge History of Strategy* — chapitres sur les traditions chinoises, romaines, mongoles, européennes modernes et contemporaines.
- *The Cambridge History of the Mongol Empire* — organisation militaire et expansion mongoles.
- Cambridge University Press, travaux sur Bismarck, la guerre limitée et l’unification allemande.
- Cambridge University Press, travaux sur Auguste, l’armée romaine et la construction de l’ordre impérial.
- U.S. Army Center of Military History — Marshall, Eisenhower, mobilisation et planification alliée.
- Naval History and Heritage Command — Nimitz, commandement du Pacifique et doctrine navale.
- Historiographie récente de la guerre du Vietnam — direction collective du Parti, rôle de Giáp et évolution stratégique.

### Tactique

- Historiographie antique et Cambridge histories pour Alexandre, Hannibal, Scipion, César et Épaminondas.
- Historiographie byzantine et critique de Procope pour Bélisaire.
- Historiographie des guerres hussites pour Jan Žižka et la diffusion du Wagenburg.
- Historiographie critique des premières conquêtes islamiques pour Khalid ibn al-Walid.
- Historiographie navale coréenne et britannique pour Yi Sun-sin et Nelson.
- Historiographie des guerres de Succession d’Espagne et de Sept Ans pour Marlborough et Frédéric II.

## Quelques références web institutionnelles/éditoriales citées pendant l’arbitrage

- Army University Press — niveaux de guerre : https://www.armyupress.army.mil/Journals/Military-Review/English-Edition-Archives/November-December-2021/Harvey-Levels-of-War/
- U.S. Army Center of Military History — stratégie et planification de coalition : https://history.army.mil/portals/143/Images/Publications/catalog/1-4.pdf
- U.S. Army Center of Military History — mobilisation et organisation : https://history.army.mil/portals/143/Images/Publications/catalog/1-2.pdf
- Naval History and Heritage Command — Chester W. Nimitz papers/biographical material : https://www.history.navy.mil/research/archives/Collections/personal-donated-collections/pd-n/nimitz-chester-w.html
- Naval History and Heritage Command — Midway, doctrine et renseignement : https://www.history.navy.mil/research/library/online-reading-room/title-list-alphabetically/m/midway-sheer-luck-or-better-doctrine.html

## Remarque finale

Cette bibliographie est un **socle de traçabilité**, non une bibliographie exhaustive des quarante biographies. Les dossiers indiquent explicitement les cas où la qualité des sources limite la précision du rang, notamment Sun Tzu, Kautilya, Han Xin et Khalid ibn al-Walid.

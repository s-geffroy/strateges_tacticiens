# Méthodologie finale

## 1. Périmètre

Deux classements autonomes, construits selon une architecture parallèle :

- **stratèges** : praticiens, dirigeants politico-militaires et théoriciens/corpus stratégiques lorsque leur influence est suffisamment démontrée ;
- **tacticiens** : commandants dont l’influence directe sur la conception ou la conduite du combat est identifiable.

Un même individu peut apparaître dans les deux classements, avec deux évaluations indépendantes.

## 2. Niveaux de guerre

- **Stratégie** : articulation des moyens militaires, politiques, économiques, diplomatiques et temporels avec les fins politiques.
- **Art opératif** : organisation des opérations et batailles en campagnes.
- **Tactique** : conduite des engagements et transformation immédiate de la situation de combat.

L’art opératif sert de **catégorie de contrôle** : une performance principalement opérative ne suffit pas à prouver une supériorité tactique ou stratégique.

## 3. Grille stratégique — 100 points de structure, sans publication d’un score final décimal

| Fonction | Poids de référence |
|---|---:|
| Conception stratégique et innovation | 20 |
| Exécution ou validation stratégique | 20 |
| Intelligence politique et systémique | 20 |
| Adaptation et apprentissage | 15 |
| Résultats rapportés aux moyens et aux coûts | 15 |
| Influence et transférabilité | 10 |

Pour un théoricien ou un corpus, « exécution » devient **validation stratégique** : institutionnalisation, capacité explicative et applications historiques. Cette adaptation permet l’admission de Clausewitz ou du corpus Sun Tzu sans inventer un commandement qu’ils n’ont pas exercé.

## 4. Grille tactique — 100 points de structure, sans publication d’un score final décimal

| Fonction | Poids de référence |
|---|---:|
| Conception du combat | 20 |
| Exécution et commandement dans l’action | 20 |
| Lecture du terrain et de l’adversaire | 20 |
| Adaptation et improvisation | 15 |
| Résultats rapportés aux moyens | 15 |
| Régularité et transférabilité | 10 |

## 5. Portes d’admissibilité

### Stratégie

Le candidat doit démontrer une influence substantielle sur plusieurs dimensions parmi : choix des objectifs, adéquation fins–moyens, allocation des ressources, coalition, adaptation, soutenabilité, conversion de la force en résultat politique et organisation de l’après-guerre.

### Tactique

Le candidat doit disposer de preuves attribuables sur : conception ou conduite du combat, adaptation sous pression, lecture de l’adversaire, usage des réserves/du tempo et répétabilité suffisante. Une seule bataille ne suffit que dans un cas exceptionnel et explicitement justifié.

## 6. Correction d’attribution

| Niveau | Sens |
|---|---|
| A | Décisions centrales directement identifiables |
| B | Direction déterminante d’un système collectif |
| C | Contribution importante mais difficile à isoler |
| D | Réputation largement construite par attribution rétrospective |

La grande échelle augmente la difficulté, mais elle réduit parfois la certitude d’attribution. Aucune victoire n’est automatiquement créditée au personnage le plus célèbre.

## 7. Corrections transversales

- **Époque** : comparaison relative aux possibilités et contraintes contemporaines.
- **Technologie** : distinguer innovation personnelle et avantage technologique hérité.
- **Documentation** : séparer faits établis, interprétations plausibles et traditions légendaires.
- **Résultat** : une bonne décision peut échouer ; une mauvaise décision peut réussir.
- **Asymétrie** : l’infériorité des moyens augmente la difficulté mais n’accorde aucun bonus automatique.
- **Offensive/défensive** : neutralité doctrinale ; attaque, défense, retraite ou dissuasion sont jugées par rapport à l’objectif.
- **Carrière** : distinguer pic de génie, constance et trajectoire complète.

## 8. Test contrefactuel

Pour chaque cas majeur :

1. informations disponibles au moment de la décision ;
2. réactions adverses plausibles ;
3. part de chance ou d’erreur adverse ;
4. alternatives disponibles ;
5. robustesse du plan si l’issue avait été moins favorable.

## 9. Incertitude

La précision du rang est limitée par la qualité documentaire et la sensibilité aux pondérations. L’appartenance au Top 12 est plus importante que l’écart exact entre deux rangs voisins.

## 10. Procédure finale

1. Longue liste.
2. Présélection.
3. Vingt dossiers comparatifs par discipline.
4. Application des critères, portes et corrections.
5. Stress tests selon plusieurs pondérations.
6. Comparaisons directes pour les candidats séparés par une faible marge.
7. Procès contradictoires des places de frontière.
8. Verrouillage des listes.

## 11. Règle de stabilité

À partir de cette version, un rang ne doit être rouvert qu’en présence d’un **élément documentaire nouveau**, d’une **erreur factuelle identifiée** ou d’une **contradiction méthodologique démontrée**.

# Classements finaux — Stratèges et tacticiens

**Version arrêtée : 11 août 2026**

Ce dossier contient la version finale des deux classements construits au cours de l’analyse :

- les **12 plus grands stratèges**, plus 8 prétendants immédiats ;
- les **12 plus grands tacticiens**, plus 8 prétendants immédiats.

## Principe central

> Le tacticien transforme une situation de combat en avantage militaire décisif. Le stratège transforme les moyens militaires, politiques, économiques et temporels en résultat politique. L’art opératif relie les deux niveaux, mais ne constitue pas ici un troisième classement.

## Structure du dossier

1. `01_methodologie_finale.md` — définitions, critères, portes, corrections et procédure d’arbitrage.
2. `02_classement_strateges_final.md` — Top 12 et huit prétendants.
3. `03_dossiers_strateges_final.md` — vingt dossiers comparatifs.
4. `04_classement_tacticiens_final.md` — Top 12 et huit prétendants.
5. `05_dossiers_tacticiens_final.md` — vingt dossiers comparatifs.
6. `06_arbitrages_finaux.md` — procès contradictoires des dernières places.
7. `07_matrice_croisee.md` — lecture stratégie × tactique.
8. `08_sources_et_regles_documentaires.md` — politique documentaire et sources de cadrage.
9. `MANIFEST.sha256` — empreintes des fichiers.

## Statut

Les listes sont **arrêtées sur le fond**. Elles peuvent être discutées historiquement, mais elles ne doivent plus être modifiées sans élément documentaire nouveau ou contradiction méthodologique démontrée. Aucun score décimal final n’est publié : les rangs résultent d’un arbitrage multicritère ordinal et d’analyses de sensibilité, afin d’éviter une fausse précision.

# Vingt dossiers comparatifs finaux — Tacticiens

> **Statut : dossiers finaux.** Les bandes provisoires du travail V2 sont conservées dans le corps comme trace du raisonnement, mais la position finale ci-dessous prévaut.

## 1. Alexandre le Grand

**Position finale : 1e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Meilleur équilibre entre pic, constance, diversité des situations, commandement personnel et forces combinées.

- **Profil :** forces combinées antiques.
- **Cas maître :** Gaugamèles.
- **Avantage décisif :** coordination phalange–cavalerie–troupes légères, lecture du moment et commandement personnel.
- **Limite :** risques personnels élevés ; instrument militaire largement construit par Philippe II.
- **Attribution :** très forte, corrigée par l’héritage macédonien.
- **Confiance documentaire :** moyenne à élevée.
- **Bande provisoire :** podium robuste.
- **Verdict :** dossier de carrière le plus complet, même si Hannibal peut conserver le plus haut pic isolé.

## 2. Napoléon Bonaparte

**Position finale : 2e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Répétabilité tactique exceptionnelle à grande échelle, malgré un déclin tardif.

- **Profil :** bataille terrestre moderne et concentration rapide.
- **Cas maître :** Austerlitz.
- **Avantage décisif :** tempo, concentration locale, corps d’armée, réserves et exploitation des erreurs adverses.
- **Limite :** adaptation déclinante dans les dernières campagnes et plans de plus en plus rigides.
- **Attribution :** très forte, avec rôle majeur des maréchaux et du système impérial.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** podium robuste.
- **Verdict :** probablement le tacticien le plus répétitif à grande échelle.

## 3. Hannibal Barca

**Position finale : 3e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Pic tactique probablement maximal avec Cannes et remarquable capacité à modeler la réaction adverse.

- **Profil :** manœuvre, enveloppement et psychologie.
- **Cas maître :** Cannes.
- **Avantage décisif :** lecture des adversaires, exploitation du terrain et provocation des réactions attendues.
- **Limite :** documentation inégale, difficultés dans les sièges et absence de décision finale en Italie.
- **Attribution :** très forte sur les batailles principales.
- **Confiance documentaire :** moyenne.
- **Bande provisoire :** podium robuste.
- **Verdict :** plus haut pic tactique plausible ; rang de carrière disputé avec Alexandre et Napoléon.

## 4. Jules César

**Position finale : 4e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Polyvalence extrême : bataille, siège, ingénierie, improvisation et commandement dans la crise.

- **Profil :** commandement adaptatif romain.
- **Cas maître :** Alésia.
- **Avantage décisif :** adaptation rapide, ingénierie, moral, vitesse et polyvalence.
- **Limite :** revers, prises de risque et sources dominées par son propre récit.
- **Attribution :** très forte, avec biais documentaire élevé.
- **Confiance documentaire :** moyenne à élevée.
- **Bande provisoire :** Top 5 probable.
- **Verdict :** son absence du premier Top 12 était une erreur méthodologique majeure.

## 5. Scipion l’Africain

**Position finale : 5e sur 20 — Top 12.**  
**Confiance : Très élevée.**  
**Motif final :** Capacité rare à apprendre de l’adversaire et à reconstruire le dispositif pour le neutraliser.

- **Profil :** adaptation tactique et contre-modélisation.
- **Cas maître :** Ilipa et Zama.
- **Avantage décisif :** apprend de l’adversaire, modifie le dispositif romain et combine cavalerie, infanterie et surprise.
- **Limite :** moins de batailles majeures documentées ; dépendance à l’alliance numide.
- **Attribution :** forte.
- **Confiance documentaire :** moyenne à élevée.
- **Bande provisoire :** Top 5–8 probable.
- **Verdict :** maître complet, sans forcément posséder le pic des trois premiers.

## 6. Yi Sun-sin

**Position finale : 6e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Exploitation exceptionnelle du terrain maritime, des courants, du feu et de l’économie des moyens.

- **Profil :** tactique navale littorale.
- **Cas maître :** Myeongnyang.
- **Avantage décisif :** exploitation des courants, du goulet, du feu et de la discipline en forte infériorité.
- **Limite :** avantages technologiques et géographiques coréens ; comparaison intermilieux délicate.
- **Attribution :** très forte.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 8–12 robuste.
- **Verdict :** candidat naval le plus solide du Top 12.

## 7. Horatio Nelson

**Position finale : 7e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Rupture du dispositif naval, commandement par intention et culture d’initiative.

- **Profil :** rupture du dispositif naval.
- **Cas maître :** Trafalgar.
- **Avantage décisif :** commandement par intention, agressivité calculée et cohésion des capitaines.
- **Limite :** supériorité qualitative britannique et dépendance à une culture navale collective.
- **Attribution :** forte, soutenue par un système supérieur.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 8–12 probable.
- **Verdict :** Top 12 justifié avec correction institutionnelle.

## 8. Épaminondas

**Position finale : 8e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Innovation structurelle du dispositif hoplitique ; petit échantillon empêchant un rang supérieur.

- **Profil :** rupture du modèle hoplitique.
- **Cas maître :** Leuctres.
- **Avantage décisif :** masse renforcée sur une aile, refus de l’autre et concentration asymétrique.
- **Limite :** petit échantillon et sources anciennes.
- **Attribution :** forte mais documentée tardivement.
- **Confiance documentaire :** moyenne.
- **Bande provisoire :** Top 8–12 probable.
- **Verdict :** doit entrer dans le Top 12 malgré un échantillon limité.

## 9. Alexandre Souvorov

**Position finale : 9e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Vitesse, simplicité, moral et offensive ; légère contamination par l’art opératif.

- **Profil :** vitesse, offensive et moral.
- **Cas maître :** campagnes contre les Ottomans et campagne d’Italie de 1799.
- **Avantage décisif :** préparation, vitesse, simplicité des ordres et audace.
- **Limite :** hagiographie et confusion fréquente entre succès tactique et opératif.
- **Attribution :** forte, mais plusieurs victoires sont collectives.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 8–12 probable.
- **Verdict :** Top 12 crédible, rang sensible à la séparation tactique–opératif.

## 10. John Churchill, duc de Marlborough

**Position finale : 10e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Très grande synchronisation de coalition et maîtrise de la fixation, du déplacement de l’effort et de l’exploitation.

- **Profil :** bataille de coalition au début du XVIIIe siècle.
- **Cas maître :** Blenheim et Ramillies.
- **Avantage décisif :** fixation, déplacement de l’effort, synchronisation alliée et poursuite.
- **Limite :** part importante d’art opératif et rôle essentiel d’Eugène de Savoie.
- **Attribution :** forte mais partagée.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 10–14.
- **Verdict :** sous-évalué dans la première liste ; duel direct nécessaire avec Frédéric et Nelson.

## 11. Arthur Wellesley, duc de Wellington

**Position finale : 11e sur 20 — Top 12.**  
**Confiance : Élevée.**  
**Motif final :** Génie de la robustesse : terrain, discipline, feu, réserves et réduction systématique du risque.

- **Profil :** défense tactique et choix du terrain.
- **Cas maître :** Salamanque et Waterloo.
- **Avantage décisif :** régularité, discipline, feu, terrain et contre-attaque au moment opportun.
- **Limite :** créativité moins spectaculaire, positions préparées et rôle des alliés à Waterloo.
- **Attribution :** forte, mais partagée dans les coalitions.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 12–18.
- **Verdict :** moins spectaculaire, mais plus robuste que plusieurs candidats mieux classés.

## 12. Bélisaire

**Position finale : 12e sur 20 — Top 12.**  
**Confiance : Moyenne.**  
**Motif final :** Meilleure économie des moyens parmi les candidats de frontière ; adaptation supérieure dans des situations dégradées.

- **Profil :** économie des moyens et défense mobile.
- **Cas maître :** Dara et défense de Rome.
- **Avantage décisif :** terrain, réserves, ruse, discipline et compensation d’une infériorité de moyens.
- **Limite :** sources dominées par Procope et plusieurs revers.
- **Attribution :** forte, avec biais documentaire important.
- **Confiance documentaire :** moyenne.
- **Bande provisoire :** Top 10–15.
- **Verdict :** Top 12 possible, rang très incertain.

## 13. Frédéric II de Prusse

**Position finale : 13e sur 20 — prétendant immédiat.**  
**Confiance : Élevée.**  
**Motif final :** Chefs-d’œuvre et profondeur de carrière, mais irrégularité, pertes et plusieurs décisions tactiques défaillantes.

- **Profil :** concentration locale et manœuvre terrestre.
- **Cas maître :** Leuthen.
- **Avantage décisif :** marche de flanc masquée, discipline et sélection du point décisif.
- **Limite :** Kunersdorf et d’autres échecs montrent une adaptation inégale ; pertes difficiles à soutenir.
- **Attribution :** très forte.
- **Confiance documentaire :** élevée.
- **Bande provisoire :** Top 8–14.
- **Verdict :** solide, mais pas automatiquement supérieur à Marlborough ou Bélisaire.

## 14. Jan Žižka

**Position finale : 14e sur 20 — prétendant immédiat.**  
**Confiance : Moyenne.**  
**Motif final :** Innovation hussite traçable et efficace, mais système et théâtre plus spécialisés.

- **Profil :** défense mobile et innovation hussite.
- **Cas maître :** chariots fortifiés, armes à feu précoces et terrains choisis contre la chevalerie.
- **Avantage décisif :** innovation, discipline et adaptation à l’infériorité.
- **Limite :** théâtre spécifique, adversaires doctrinalement rigides et documentation inégale.
- **Attribution :** forte.
- **Confiance documentaire :** moyenne.
- **Bande provisoire :** Top 13–20.
- **Verdict :** candidat important, mais transférabilité et échantillon limitent le Top 12.

## 15. Khalid ibn al-Walid

**Position finale : 15e sur 20 — prétendant immédiat.**  
**Confiance : Faible à moyenne.**  
**Motif final :** Potentiel très élevé, mais résolution documentaire trop faible pour une douzième place mondiale.

- **Profil :** mobilité et adaptation dans les premières conquêtes islamiques.
- **Cas maître :** Yarmouk selon la tradition.
- **Avantage décisif :** mobilité des réserves, redéploiement et cohésion dans des campagnes rapides.
- **Limite :** sources tardives, effectifs contestés et reconstruction héroïque possible.
- **Attribution :** probable, difficile à isoler précisément.
- **Confiance documentaire :** faible à moyenne.
- **Bande provisoire :** places 8–18.
- **Verdict :** Top 12 plausible ; une cinquième place précise n’est pas soutenable.

## 16. Louis-Nicolas Davout

**Position finale : 16e sur 20 — prétendant immédiat.**  
**Confiance : Élevée.**  
**Motif final :** Auerstaedt est un chef-d’œuvre, mais l’échantillon de commandement autonome reste trop étroit.

- **Profil :** commandement de corps sous contrainte.
- **Cas maître :** Auerstaedt.
- **Avantage décisif :** discipline, préparation, sang-froid et manœuvre défensive-offensive.
- **Limite :** faible nombre de commandements totalement autonomes ; dépend du système napoléonien.
- **Attribution :** très forte à Auerstaedt.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 13–18.
- **Verdict :** prétendant majeur, limité par la profondeur de carrière autonome.

## 17. Nader Shah

**Position finale : 17e sur 20 — prétendant immédiat.**  
**Confiance : Moyenne à élevée.**  
**Motif final :** Maîtrise du feu mobile et de la manœuvre, mais part opérative importante et adversaires de qualité inégale.

- **Profil :** feu mobile et manœuvre persane.
- **Cas maître :** Karnal.
- **Avantage décisif :** combinaison cavalerie, mousquets et artillerie légère.
- **Limite :** qualité inégale des adversaires et part importante de l’opératif et de l’organisation.
- **Attribution :** forte.
- **Confiance documentaire :** moyenne à élevée.
- **Bande provisoire :** Top 13–20.
- **Verdict :** très grand commandant ; son ancien rang 10 n’était pas démontré.

## 18. Han Xin

**Position finale : 18e sur 20 — prétendant immédiat.**  
**Confiance : Faible à moyenne.**  
**Motif final :** Créativité potentiellement exceptionnelle, mais sources trop tardives et littéraires pour un rang précis.

- **Profil :** manœuvre chinoise antique.
- **Cas maître :** campagnes d’unification Han.
- **Avantage décisif :** créativité, guerre de mouvement, surprise et exploitation psychologique.
- **Limite :** sources littéraires tardives et épisodes possiblement embellis.
- **Attribution :** moyenne.
- **Confiance documentaire :** faible à moyenne.
- **Bande provisoire :** Top 12–20.
- **Verdict :** potentiel Top 12, mais non classable avec une précision moderne.

## 19. Subutaï

**Position finale : 19e sur 20 — prétendant immédiat.**  
**Confiance : Moyenne.**  
**Motif final :** Génie surtout opératif : coordination de colonnes et campagnes continentales plutôt que conduite tactique stricte.

- **Profil :** commandement opératif mongol.
- **Cas maître :** campagne européenne de 1241.
- **Avantage décisif :** colonnes séparées, renseignement, feintes, synchronisation et concentration à grande distance.
- **Limite :** qualités principalement opératives ; attribution partagée avec les princes et le système mongol.
- **Attribution :** moyenne à forte selon les campagnes.
- **Confiance documentaire :** moyenne.
- **Bande provisoire :** Top 3 opératif, frontière tactique.
- **Verdict :** probablement hors Top 12 tactique strict sans être déclassé comme commandant.

## 20. Konstantin Rokossovski

**Position finale : 20e sur 20 — prétendant immédiat.**  
**Confiance : Très élevée.**  
**Motif final :** Maître de l’art opératif interarmes ; la preuve tactique personnelle est plus indirecte.

- **Profil :** commandement interarmes soviétique.
- **Cas maître :** opération Bagration.
- **Avantage décisif :** préparation, concentration, artillerie, tromperie et défense de choix opératifs cohérents.
- **Limite :** Bagration relève surtout de l’art opératif ; attribution collective et supériorité soviétique.
- **Attribution :** forte sur son front, collective au niveau global.
- **Confiance documentaire :** très élevée.
- **Bande provisoire :** Top 15–20 tactique ; sommet opératif probable.
- **Verdict :** important, mais mal catégorisé parmi les tacticiens stricts.

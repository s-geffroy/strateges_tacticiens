# Classement final — Les 12 plus grands stratèges

> **Statut : classement final arrêté.**

## Top 12

| Rang | Candidat | Confiance Top 12 | Motif synthétique |
|---:|---|---|---|
| **1** | **Gengis Khan** | Très élevée | Construit un système de guerre et de conquête extensible qui dépasse sa personne. |
| **2** | **Otto von Bismarck** | Très élevée | Maîtrise exemplaire de la limitation politique de la guerre et de l’après-victoire. |
| **3** | **Mao Zedong** | Très élevée | Intègre politique, mobilisation, temps long, guerre irrégulière et guerre conventionnelle. |
| **4** | **Napoléon Bonaparte** | Très élevée | Maîtrise militaire exceptionnelle, limitée par l’incapacité finale à stabiliser l’ordre européen. |
| **5** | **Scipion l’Africain** | Élevée | Déplace le théâtre, désarticule la base carthaginoise et convertit l’apprentissage en décision politique. |
| **6** | **Tokugawa Ieyasu** | Élevée | Allie patience, coalition, conservation des forces et institutionnalisation durable de la victoire. |
| **7** | **Auguste** | Élevée | Transforme la victoire civile en architecture militaire et politique durable, avec attribution opérationnelle partagée. |
| **8** | **Mehmed II** | Élevée | Combine technologie, siège, diplomatie, coercition et consolidation impériale. |
| **9** | **Carl von Clausewitz** | Élevée | Fournit la théorie la plus puissante de la guerre comme instrument politique, malgré une validation personnelle limitée. |
| **10** | **Sun Tzu — corpus attribué** | Élevée pour le corpus | Corpus majeur sur information, tromperie, asymétrie et économie de la coercition ; l’individu historique demeure incertain. |
| **11** | **George C. Marshall** | Moyenne à élevée | Construit l’appareil américain capable de soutenir une guerre mondiale et sélectionne les instruments humains de son exécution. |
| **12** | **Võ Nguyên Giáp** | Moyenne | Résultat politique disproportionné aux moyens initiaux ; attribution collective et coûts empêchent un rang supérieur. |

## Huit prétendants immédiats

| Rang | Candidat | Confiance / statut | Motif de non-admission |
|---:|---|---|---|
| **13** | **Chester W. Nimitz** | Moyenne | Commandement de théâtre exceptionnel, mais contribution moins globale que Marshall et moins politico-stratégique que Giáp. |
| **14** | **Frédéric II de Prusse** | Moyenne | Survie remarquable face à une coalition supérieure, mais risques auto-infligés et dépendance aux événements extérieurs. |
| **15** | **Pierre le Grand** | Moyenne | Transformation militaire et étatique majeure, mais victoire lente, coûteuse et partiellement structurelle. |
| **16** | **Dwight D. Eisenhower** | Moyenne | Commandant de coalition remarquable, mais auteur seulement partiel de la grande stratégie alliée. |
| **17** | **Alexandre le Grand** | Élevée | Conquête fulgurante et maîtrise militaire immense, mais faiblesse de la succession et de la stabilisation. |
| **18** | **Helmuth von Moltke l’Ancien** | Élevée | Maître de l’art opératif ; autonomie politico-stratégique limitée par la primauté de Bismarck. |
| **19** | **Kautilya — Arthashastra** | Moyenne | Corpus systémique de gouvernement et de puissance, mais attribution et validation opérationnelle insuffisantes. |
| **20** | **Joseph Staline** | Élevée sur les faits, rang faible | Capacité de mobilisation existentielle réelle, contrebalancée par des erreurs initiales et des coûts extrêmes. |

## Lecture du rang

Le rang récompense la capacité à transformer la puissance disponible en résultat politique. Il ne s’agit ni d’un classement des conquérants, ni d’un classement des meilleurs généraux de bataille.
